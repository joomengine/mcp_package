<?php
/**
 * @package    JoomEngine.Mcp
 * @created    18 September 2026
 * @author     Llewellyn van der Merwe <https://dev.vdm.io>
 * @copyright  Copyright (C) 2026 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 3 or later; see LICENSE
 */
namespace VDM\Component\JoomEngineMcp\Administrator\Model;


/**
 * Native action adapter bound to the fixed catalogue schema.
 *
 * @since  0.1.0
 */
final class ActionModel extends DefinitionModel
{
	/** @var string Fixed definition identity. @since 0.1.0 */
	protected const ENTITY = 'action';

	/** @var string Native Joomla message prefix. @since 0.1.0 */
	protected $text_prefix = 'COM_JOOMENGINE_MCP_ACTION';
}
