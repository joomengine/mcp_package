# Implementation status — 28 September 2026

## Branch

The migration [PR #1](https://github.com/joomengine/mcp_plugin/pull/1) is merged. First-package release readiness is on `fix/first-package-release`; the [component acceptance checklist](https://github.com/joomengine/mcp_component/pull/1#issuecomment-5732685349) tracks coordinated Joomla/JCB execution evidence.

Plugin version 0.1.0 requires component version 0.1.1 or later within the same major version, because the explicit JCB synchronization operation is part of that runtime contract.

## Implemented runtime

Exact plugin element/group/namespace, Joomla DI/event integration, lazy adapters for serve/describe/dispatch/self-test/cli-inventory/jcb-sync, local-only checks and shared typed component runtime resolution are present. The output guard isolates protocol framing from Joomla diagnostics. Installer checks, initial enablement with update-state preservation and language metadata are implemented. The tracked source is directly installable; no plugin ZIP builder is maintained here.

The component supplies ConsoleRuntimeInterface/ConsoleRuntimeProviderInterface and the runtime composition. The plugin forwards native input/output objects and exact exit status; it contains no JCB catalogue or business handlers. Registration checks all MCP names before mutation, binds native global options before selecting protocol output protection, and restores formatter state after successful execution and native application errors.

The component's existing installed stdio suite exercises its shared runtime directly. This repository now also has an installed workflow which installs this plugin checkout and tests `cli/joomla.php joomla:mcp:*`, including the real `serve` adapter. These are distinct evidence layers.

## Current scope update

External Composer-client/remote-stdio ownership is exclusively in `joomengine/mcp_client`; the server and plugin do not depend on it. Full JCB API/CLI support remains mandatory, with the plugin boundary documented in JCB-INTEGRATION.md and actual source/execution evidence maintained by the component.

JCB handlers, reviewed command/API bindings, input freezing, jobs and artifacts belong to the component. The plugin consumes them through its existing shared runtime. Its console adapters do not re-register JCB's native commands or depend on the external client. The canonical JCB acceptance matrix remains docs/JCB-INTEGRATION.md and the component roadmap.

## Historical verification layers

The following installed/runtime results belong to the recorded September 24 revisions. The former ZIP/release-asset implementation is replaced by source-archive installation and OctoShoom; current checks are recorded in the release-alignment PR.

Local PHP 8.3.6 verification: syntax, manifest/language/reproducible package checks; 29 assertions using genuine Joomla 6.1.3 console/plugin/input/output classes; and five release metadata assertions. The native class suite verifies idempotent/atomic registration, global-option handling, help/core output preservation, error restoration, lazy runtime resolution, native input forwarding and nonzero statuses. It uses a substitutable shared-runtime implementation and is not an installed JCB execution test.

The installed suite covers the actual plugin's describe/self-test/inventory/dispatch adapters, JSON/NDJSON framing and nonzero outcomes, EOF/byte bounds, MCP handshake/discovery/native action execution through `serve`, and component-disabled/core-command isolation. All 18 installed assertions passed on Joomla 6.1.3 / MySQL with PHP 8.3 and 8.4, together with the component's installation, administrator, HTTP, native CRUD, upgrade and uninstall suites.

Four of these assertions cover NDJSON boundaries: oversized spaces, tabs and non-JSON input each return `REQUEST_TOO_LARGE`, while bounded blank frames and a valid request exactly at the one-MiB wire limit remain accepted. These exercise the shared component runtime through the installed plugin, including the component fix that checks frame size before ignoring whitespace. The 24 September local review also reran the 29 native Joomla assertions, reproducible package checks and five release metadata assertions successfully.

Verified runtime and test revision: plugin `3526cae818803a02971374c044a2e2184f1c2c61`.

- [Native console, package and release metadata CI](https://github.com/joomengine/mcp_plugin/actions/runs/35983036798): passed on PHP 8.3 and 8.4.
- [Installed console plugin CI](https://github.com/joomengine/mcp_plugin/actions/runs/35983036883): all 18 plugin assertions passed on PHP 8.3 and 8.4, including actual plugin entrypoints and the component/package lifecycle. Exact checked-out revisions are retained in that run's logs.
- [Coordinated installed core matrix](https://github.com/joomengine/mcp_component/actions/runs/35983426742): all four PHP 8.3/8.4 and MySQL 8.4/PostgreSQL 16 jobs passed. Component `75d9685268332241de846935aad2edc2e92c8459` pins this plugin revision and client `72d02491fe80dadc581d3d9d67b1dfbc917d095d`; the matrix exercises the installed plugin and authenticated remote client alongside the component.

These installed core fixtures have no JCB installation. The component's golden-image workflow installs a pinned version of this plugin alongside JCB and runs the same actual-entrypoint suite; its JCB operation matrix supplies the separate compiler/package/job evidence. The verified golden-image revisions, results and inherited native limitations are recorded in the [component acceptance checklist](https://github.com/joomengine/mcp_component/pull/1#issuecomment-5732685349).

Installed CI uses the component's main branch by default; configuration and reusable callers can select an explicit component revision. Manual next-version releases freeze both changelogs and manifest metadata, create an immutable tag, append its source ZIP to the Joomla update feed, and invoke `octoleo/octoshoom@master` directly. Authentication and signing use `octoleo/git-user@v2`; custom SSH setup, temporary action checkouts and duplicate hash checks have been removed. Existing tags and feed entries are left unchanged on rerun. This plugin never builds a combined package or invokes OctoJPack. See RELEASE.md. No release has been run by this implementation work.

The simplified release support passes actionlint, PHP 8.3 syntax checks, 13 isolated metadata checks, and the source manifest/language/installation-completeness checks. These checks do not exercise publication credentials or replace the installed runtime evidence above.

The first-package readiness changes pass 18 isolated release metadata checks and the source manifest/language/installation-completeness checks on PHP 8.3.6. These include native feed identity/information, rejection without file changes for reused or unprepared versions and misplaced pending markers, and checksum preservation across retries and successive releases. Runtime code is unchanged. Release instructions now cover both independent plugin workflows before the component's package release; actual publication still requires running those workflows with configured credentials.

The component golden-image suite exercises shared JCB operations, native options/dependencies, persisted read-back, generated/install artifacts, state isolation, long jobs/cancellation/recovery and cleanup. Each result belongs to its recorded component/JCB/plugin revisions. The linked PR and acceptance checklist are authoritative for current completion; historical runs do not certify later runtime changes. External-client interoperability is tracked in `mcp_client` and the coordinated component suite. Review/merge and deliberate release publication remain separate actions.
