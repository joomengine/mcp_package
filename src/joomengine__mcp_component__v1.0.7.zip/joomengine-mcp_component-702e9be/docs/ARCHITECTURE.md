# Architecture — JoomEngine MCP

## Scope, identities and ownership

`com_joomengine_mcp` uses `VDM\Component\JoomEngineMcp` with Joomla's Administrator, Site and Api suffixes. `plg_console_joomengine_mcp` uses `VDM\Plugin\Console\JoomEngineMcp` in `joomengine/mcp_plugin`. This repository owns the installed server and its Composer-managed server dependencies only. External PHP client/remote stdio work belongs to `joomengine/mcp_client`; see CLIENT-HANDOFF.md.

The delivery target includes all preserved Joomla core MCP capabilities **and the complete JCB API and CLI surface**. Read integrations/JCB.md for the source-pinned integration and remaining inventory/implementation work. JCB is optional on a particular installation, but its full support is mandatory for completion of this project.

Joomla 6 contracts are authoritative. Repository placement follows JCB: root `joomengine_mcp.xml`, installer, `admin/`, `api/`, `site/`, `media/`, changelog/update metadata and `.octojpack`. Administrator code uses native MVCFactory, src/Controller/Model/View/Table, forms, tmpl, layouts, language, services/provider.php, access.xml/config.xml and versioned SQL. This is hand-authored JCB-aligned source, not an imported blueprint.

## HTTP path

AI/MCP client → Joomla API entry point → Joomla API-token authentication → non-public MCP route → component controller/transport boundary → protocol engine → database catalogue/authorizer → reviewed action binding → Joomla/JCB API or explicitly authorized native service → verification/audit → JSON-RPC response.

Joomla route registration belongs to `joomengine/mcp_webservices`, a separately installable plugin. Local console entry belongs to `joomengine/mcp_plugin`. OctoJPack combines both plugins with the component in `joomengine/mcp_package`; the component installer never manages either plugin. The webservices plugin registers routes only while the component is enabled, enables itself on initial installation and preserves operator state on updates.

Reuse Joomla token authentication, not a second credential store. Verify both supported Joomla token header forms against the installed API authentication plugin. Static token authentication is not OAuth discovery; do not advertise an OAuth authorization server that is not implemented.

Outbound API calls use a server-configured canonical same-site origin, reviewed relative routes, bounded bytes/time, verified TLS and no redirects. They preserve the caller's token and target ACL. This server-only HTTP adapter lives in admin/src/Http. HTTP requests cannot invoke the trusted local CLI context. JCB command jobs use a reviewed service boundary that retains and rechecks the original API user's authority inside the worker.

## Trusted console path

Joomla console application → console plugin → CLI-only composition root → shared database catalogue/engine → reviewed Joomla/JCB native or registered-console adapter.

The owner explicitly defines server possession as the local authority boundary. No API token or row viewing permission is needed locally, but input/schema validation, bounded execution, provenance, grants/action semantics, verification and recovery remain. HTTP data cannot construct that authority. Wire transport and execution authority are different concepts: a remote stdio bridge is still an HTTP-token-restricted client.

JCB command registration must remain owned by its installed console plugin. The MCP adapter discovers and invokes exact reviewed command objects with typed arguments after registration is complete, preserving names, stdout/stderr and exit/result semantics. Definitions and handlers remain shared with the component; do not duplicate the JCB catalogue in the console plugin.

## Database-defined capabilities and JCB

Published provider, schema, action, binding, tool, resource, prompt and CLI-target records define discovery. Explicit DI services implement reusable primitives. Action/binding records carry schemas, effects, permissions, compatibility and mappings; no row can instantiate arbitrary code. Existing primitives enable extension by validated rows. New primitives require reviewed handler services before corresponding rows can become executable.

Permission request schemas accept bounded toolset names so installed providers can add write scopes such as `jcb.execute`. The permission service checks every requested scope against currently published, authorized write actions at request, approval and use. `data/runtime-tools.json` declares this extension to the original core-only input enum; generated database schemas retain its provenance. Upgrades preserve the original schema for administrator-owned tools with deliberately narrower policies.

The JCB provider uses `com_componentbuilder` dependency/version metadata and stable source identities. Explicit synchronization also inventories registered APIs for enabled installed third-party components under per-component native administration authority. The MCP component and exact Joomla core component identities from `ExtensionHelper::getCoreExtensions()` are excluded from this generated scope; existing core definitions remain authoritative. Extension `protected`/`locked` flags are not API ownership or permission boundaries. Each selected component has its own provider, route ownership and plugin dependencies. Reuse schemas and binding mechanics across actual routes and registered command families. Do not generate routes from table names or a get/init/pull/push/reset Cartesian product from the package entity map. Source inventory, runtime availability and tested support are separate. Missing/disabled JCB hides its runnable definitions without harming Joomla core or unrelated installed component APIs.

Installed form contracts come from confined, literal API-controller/model/form mappings during synchronization. Source hashes bind their field/filter/default/conditional/subform descriptors to generated schemas and verification metadata. Native defaults are descriptive and do not populate omitted PATCH fields; native validators and ACL remain authoritative. Only a declared required primary GUID without a default or detected server-generation rule may be generated before approval, disclosed in the plan and retained in its immutable input. Related record identifiers are never generated.

Generated CRUD bindings preserve reviewed numeric, GUID and unique-key route identities and fixed defaults. Plans freeze their independent item-read revision; snapshots and mutation read-back must identify the same resource. Native form representation rules permit only declared comparisons, while object/list shape, row keys, list order and undeclared values remain strict. Request-only controls are disclosed separately. Unsupported specialized tasks retain diagnostics; source/fixture coverage is not live installed API parity. See IMPLEMENTATION.md for current evidence and upstream limits.

Viewing levels resolve groups through Joomla; each editable row has an asset_id. Provider state, record publication, authorized view levels, asset/action ACL, handler availability, target ACL, version compatibility and track are independent checks. Apply the same predicate to discovery/search/describe/direct calls and recheck at execution.

## Protocol, durable state and long-running work

Advertise only protocol revisions/features actually implemented and tested. The existing PHP SDK integration supports multiple protocol eras; do not mix legacy session/initialize requirements with the stateless revision. Optional SSE subscriptions, notifications and tasks must not be advertised merely because a dependency offers them. Stdio stdout contains only protocol frames.

Plans, grants, idempotency, locks and audit persist in the database across PHP workers. Approvals bind principal, action, canonical validated input, definition revision and expiry. Atomically claim one-shot state, re-authorize before execution and preserve ambiguous/partial effects for reconciliation instead of replaying writes.

JCB compilation and dependency synchronization use durable owned jobs, one-use worker tickets, lease state, progress, cancellation and artifact IDs/hashes. A timed-out connection is neither cancellation nor rollback. Planning freezes native options/environment values and definition/configuration fingerprints; separate PHP execution processes isolate mutable JCB containers. Expired or ambiguous work remains uncertain for reconciliation; only never-started queued jobs can be redispatched. Artifacts are retained privately with ownership, bounded byte reads, chunk integrity and expiry enforcement.

## Administrator experience

Native singular edit/plural list screens cover providers, schemas, actions, bindings, tools, resources, prompts and CLI targets, including relationships/subforms, filtering, ordering, publication, access/assets, validation and checkout. Provide audit/execution/job inspection, grant revocation and uncertain-execution reconciliation. Keep reusable logic out of generated-style controllers and use native language/Web Asset Manager conventions.

JCB source-code fields remain permitted inert definition data under appropriate permissions. They are not executable MCP dispatch strings. Compiling/installing extensions or running JCB hooks is a separate high-risk permission and confirmation boundary.

## Distribution and references

This repository is a directly installable component source tree, with production dependencies and installation data committed in place. MySQL/MariaDB and PostgreSQL schema updates and customization-preserving JSON seed updates remain installer-owned. Both plugins have independent repositories and native installers. Manual version releases tag the component, update its component-only feed and hash its tagged archive, then use the standalone `.octojpack` configuration to publish the combined package with the same version. The package tag starts its own update-feed and OctoShoom workflow in `mcp_package`, whose `.github` directory survives package replacement. See RELEASE.md.

- Original MCP: https://github.com/joomengine/joomla-mcp/tree/2cff50f4f6b440da3c684f9995a77efad32e1a36
- Joomla/JCB layout: https://github.com/joomengine/Joomla-Component-Builder/tree/6.x
- JCB required integration: https://github.com/extension-builder/joomla/tree/5ee658dd07eb749dca43ed4722f6cca7eb8208cf
- CLI documentation: https://github.com/joomengine/jcb-documentation/blob/ecd3670232d344295fc4f673b2d3dc40a64b3bf6/english/CLI-Command-Suite.md
- PHP style: https://github.com/extension-builder/joomla/blob/main/docs/development/php-code-style.md
